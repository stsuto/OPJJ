/**
 * Package contains the class <code>ComplexNumber</code> necessary to create and work with complex numbers.
 * This package also contains the subpackage demo that has a demonstration of the class <code>ComplexNumber</code>.
 * demonstration of which is placed in the subpackage demo.
 */
package hr.fer.zemris.java.hw02;