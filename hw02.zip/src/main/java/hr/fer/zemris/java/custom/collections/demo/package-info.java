/**
 * This subpackage contains the demonstration class for its parent-package collection classes.
 * 
 */
package hr.fer.zemris.java.custom.collections.demo;