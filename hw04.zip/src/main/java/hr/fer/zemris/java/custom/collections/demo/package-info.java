/**
 * This subpackage contains all examples that demonstrate the 
 * functionalities of the classes defined in parent-package.
 */
package hr.fer.zemris.java.custom.collections.demo;