package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * Class <code>DocumentNode</code> is an extension of <code>Node</code>. 
 * It is representation of one entire document.
 * 
 * @author stipe
 */
public class DocumentNode extends Node {

	@Override
	public void accept(INodeVisitor visitor) {
		visitor.visitDocumentNode(this);
	}

}
