/**
 * Package contains class Node and its more specific extending classes for representations of structured documents.
 * Classes from this package are used for syntax analysis.
 */
package hr.fer.zemris.java.custom.scripting.nodes;