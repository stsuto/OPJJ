/**
 * Package contains class Element and its more specific extending classes for representations of expressions.
 * Classes from this package are used for syntax analysis.
 */
package hr.fer.zemris.java.custom.scripting.elems;