/**
 * Package contains all classes and enumerations necessary to create a lexer 
 * and provide lexical analysis of a document.
 */
package hr.fer.zemris.java.hw03.prob1;