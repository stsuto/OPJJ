/**
 * Package contains class <code>SmartScriptParser</code> which is used for syntax analysis and class 
 * <code>SmartScriptParserException</code> which is the exception thrown in case of parsing failure.
 */
package hr.fer.zemris.java.custom.scripting.parser;