/**
 * This package contains demo classes which demonstrate the functionality of some smaller classes
 * and of the class which offers complete functionality of database querying.
 */
package hr.fer.zemris.java.hw05.db.demo;
