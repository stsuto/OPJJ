/**
 * This package contains classes and strategy interfaces used for student information storage and modeling conditional expressions,
 * and also parser for syntax analysis of users query inputs.
 */
package hr.fer.zemris.java.hw05.db;
