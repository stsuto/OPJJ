/**
 * This package contains all classes and enumerations for lexical analysis and creation of tokens of
 * appropriate types.
 */
package hr.fer.zemris.java.hw05.db.lexer;
