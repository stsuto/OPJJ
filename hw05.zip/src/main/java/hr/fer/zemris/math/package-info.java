/**
 * This package contains a class representing a 2D vector model used for representing positions
 * and directions within a coordinate system. 
 */
package hr.fer.zemris.math;