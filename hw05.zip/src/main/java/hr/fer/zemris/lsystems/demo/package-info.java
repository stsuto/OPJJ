/**
 * This package contains demo classes for other classes from this parent-package.
 * The demo classes offer graphic representation by drawing fractals.
 */
package hr.fer.zemris.lsystems.demo;
